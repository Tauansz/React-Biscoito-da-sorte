import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      textoFrase: '',
      img: require('./assets/biscoito.png'),
    };
    this.quebraBiscoito = this.quebraBiscoito.bind(this);
    this.frases = [
      'Expectativa é igual paçoca, do nada esfarela tudo.',
      'De longe parece derrotado, de perto parece que está longe.',
      'Por causa de gente como você é que na caixa de ovo vem escrito: "Contém ovo".',
      'O segredo do sucesso é fazer o contrário do que você está fazendo.',
      'O mérito da derrota é todinho seu, orgulhe-se.',
      'É só uma fase ruim, logo vai piorar.',
      'Nunca subestime sua incapacidade.',
      'Acreditar que você consegue já é meio caminho para o fracasso.',
      'Nunca foi azar, sempre foi incompetência!',
    ];
  }

  quebraBiscoito() {
    let numeroAleatorio = Math.floor(Math.random() * this.frases.length);
    this.setState({
      textoFrase: '"' + this.frases[numeroAleatorio] + '"',
      img: require('./assets/biscoitoAberto.png'),
    });
  }

  render() {
    return (
      <View style={styles.container}>
        <Image
          source={this.state.img}
          style={styles.img} // Correção de "style" para "styles"
        />
        <Text style={styles.textoFrase}>{this.state.textoFrase}</Text>

        <TouchableOpacity
          style={styles.botao}
          onPress={this.quebraBiscoito} 
        >
          <View style={styles.btnArea}> 
            <Text style={styles.btnTexto}>Descubra a sua frase de vida</Text> 
          </View>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  img: {
    width: 250,
    height: 250,
    marginBottom: 20,
  },
  textoFrase: {
    fontSize: 20,
    color: '#dd7b22',
    margin: 20,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  botao: {
    width: 230,
    height: 40,
    borderWidth: 2,
    borderColor: '#dd7b22',
    borderRadius: 25,
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  btnArea: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  btnTexto: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#dd7b22',
    textAlign: 'center',

  },
});

export default App;
